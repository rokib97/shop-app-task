import "./App.css";
import AddShop from "./components/AddShop";
import Header from "./components/Header";

function App() {
  return (
    <div>
      <Header />
      <AddShop />
    </div>
  );
}

export default App;
